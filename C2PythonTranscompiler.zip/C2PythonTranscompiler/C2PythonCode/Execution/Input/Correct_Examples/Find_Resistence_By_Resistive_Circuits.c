//Individuare resistenza equivalente, a partire da una combinazione di circuiti resistivi in parallelo

int main() {
   int r[10], num, i, rs = 0;

   printf("Enter the number of Resistances : ");
   scanf("%d", &num);

   printf("\nEnter Value of Each Resistance : ");
   for (i = 0; i < num; i++) {
      printf("\n R%d : ", i + 1);
      scanf("%d", &r[i]);
   }

   for (i = 0; i < num; i++) {
      rs = rs + r[i];
   }

   printf("\nEquivalent Series Resistance : %d Kohm", rs);
   return (0);
}
