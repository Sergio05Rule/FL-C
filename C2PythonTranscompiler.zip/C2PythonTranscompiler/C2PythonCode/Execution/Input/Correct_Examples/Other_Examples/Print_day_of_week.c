//STAMPA GIORNO DELLA SETTIMANA
int main()
{
  int weekday;
  printf(" Please Enter the Day Number 1 to 7 (Consider 1= Monday, and 7 = Sunday) :  ");
  scanf("%d", &weekday);

  if (weekday == 1)
  {
        printf("\n Today is Monday");
  }
  if ( weekday == 2 )
  {
        printf("\n Today is Tuesday");
  }
  if ( weekday == 3 )
  {
        printf("\n Today is Wednesday");
  }
  if ( weekday == 4 )
  {
        printf("\n Today is Thursday");
  }
  if ( weekday == 5 )
  {
        printf("\n Today is Friday");
  }
  if ( weekday == 6 )
  {
        printf("\n Today is Saturday");
  }
  if ( weekday == 7 )
  {
        printf("\n Today is Sunday");
  }
  if (weekday <1 || weekday >7)
    printf("\n Please enter Valid Number between 1 to 7");

  return 0;
}

