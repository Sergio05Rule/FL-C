//SOMMA DI NUMERI NATURALI IN UN LOOP

  int main()
  {
      int n, count, sum = 0;

      printf("Enter the value of n(positive integer): ");
      scanf("%d",&n);

      for(count=1; count <= n; count++)
      {
          sum = sum + count;
      }

      printf("Sum of first %d natural numbers ",n);
      printf("is: %d", sum);

      return 0;
  }



