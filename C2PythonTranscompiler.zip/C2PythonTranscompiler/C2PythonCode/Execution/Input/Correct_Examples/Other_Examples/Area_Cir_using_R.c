//CALCOLA AREA DELLA CIRCONFERENZA SULLA BASE DEL RAGGIO INSERITO DALL’UTENTE

int main()
{
   int circle_radius;
   float pi_value=3.14, circle_area, circle_circumf;

   //Ask user to enter the radius of circle
   printf("\nEnter radius of circle: ");
   //Storing the user input into variable circle_radius
   scanf("%d",&circle_radius);

   //Calculate and display Area
   circle_area = pi_value * circle_radius * circle_radius;
   printf("\nArea of circle is: %f",circle_area);

   //Caluclate and display Circumference
   circle_circumf = 2 * pi_value * circle_radius;
   printf("\nCircumference of circle is: %f",circle_circumf);

   return(0);
}

