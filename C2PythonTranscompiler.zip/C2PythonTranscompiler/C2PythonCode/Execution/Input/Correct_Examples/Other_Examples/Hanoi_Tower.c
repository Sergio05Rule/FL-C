//TORRI DI HANOI 

    void toh(int num, char x, char y, char z) {
       if (num > 0) {
          toh(num - 1, x, z, y);
          printf("\n%c ->", x);
          printf("%c", y);
   toh(num - 1, z, y, x);
       }
    }


  int main() {
     int num;
     printf("\nEnter number of plates:");
     scanf("%d", &num);

    toh(num - 1, 'A', 'B', 'C');
     return (0);
  }

