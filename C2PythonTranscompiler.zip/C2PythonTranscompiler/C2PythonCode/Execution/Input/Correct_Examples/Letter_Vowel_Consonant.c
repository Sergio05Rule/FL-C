//Indicare se la lettera inserita è una vocale o una consonante  
int main()
  {
      char line;
      int vowels = 0;
      int consonant = 0;
      int digit = 0;

      printf("Enter a letter: ");
      scanf("%c",&line);



      if (line == 'a' || line == 'e' || line == 'i' ||
          line == 'o' || line == 'u' || line == 'A' ||
          line == 'E' || line == 'I' || line == 'O' ||
          line == 'U')
          {
            printf("%c is a Vowel\n",line);
          }
      else
	  {
	    printf("%c is a Consonant\n",line);
	  }
      return 0;
  }
