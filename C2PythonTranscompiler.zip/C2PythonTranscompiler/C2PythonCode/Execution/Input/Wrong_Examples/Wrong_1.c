int i;

int main()
{
  int i;
  int i=0;  // Blocking error in Symbol Table population. Variable has already been declared in this scope.

}
