void maggiore_minore(double a, double b)
{
  if( a < b )
  printf("il primo numero è minore del secondo!" );
  else
  {
      if( b < "a") //Blocking error: it is not possible to compare a double variabile to a constant string
      printf("il primo numero è maggiore del secondo!" );
      else
      printf("i due numeri sono uguali!");
  }

  return;
}


int main()
{
    double a,b;

    printf("Inserisci il primo numero:\n");
    scanf("%lf", &a);

    printf("Inserisci il secondo numero:\n");
    scanf("%lf", &b);

    maggiore_minore(a,b);

}
