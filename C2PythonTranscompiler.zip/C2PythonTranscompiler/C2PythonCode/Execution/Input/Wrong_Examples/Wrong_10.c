int main()
{
    char c[3] = "ciao"; //Warning reported: string oversizes array dimension
    char v1[10][3] = {"toolong", "ok"}; //Warning reported: string "toolong" oversizes matrix maximum dimension
    char v[10] = {"ciao", "ciao"}; //Blocking error: only one element can be initialized in one-dimension char array
}
