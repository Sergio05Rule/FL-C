int main()
{
    char c = 'cc'; //Warning reported: there's a multi-character constant
    char c2 =''; //Blocking error: empty character constant

}
