int i;
int value = i; // Blocking error: it is not possible to instantiate a variable using another variable, in global scope.
	       //Otherwise, it is possible in different scopes.


int main()
{


}
