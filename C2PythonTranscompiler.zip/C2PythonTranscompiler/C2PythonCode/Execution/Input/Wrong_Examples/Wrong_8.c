int main()
{
    int a,b;
    int v[-10] = {99,54,33,44,12,67,89}; //Blocking error: array has negative dimension value

}
