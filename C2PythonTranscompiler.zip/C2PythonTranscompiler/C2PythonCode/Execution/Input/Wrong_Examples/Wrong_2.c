int test()
{

}


void test() //Blocking error in Symbol Table population. Function has already been declared with another type at line 1
{

}

int main()
{


}
