void sum_two_value(double a, double b)
{

  double c = a + b;

  return c; //Warning has been reported returning a non-void value in void function.
}


int main()
{
    double a,b;
    double result = 0;

    printf("Inserisci il primo numero:\n");
    scanf("%lf", &a);

    printf("Inserisci il secondo numero:\n");
    scanf("%lf", &b);

    result = sum_two_value(a,b); //Blocking error: a void value has been assigned to a double variable.

}
