
int main()
{

double var[10] = {"ciao"} ; //Blocking error: it is not possible to initialize a double vector variable, using char(the decleared has to be of char type).

}
