
void test(int var)
{
  printf("%d",var);
}


int main()
{
    int i;
    test(i);
    printf("%d",var); //Blocking error: variable has not been declared in the actual scope
}
