# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	r: int = np.full((10), 0, dtype=object)
	num: int = 0
	i: int = 0
	rs: int = 0
	print("Enter the number of Resistances : ", end='')
	num = int(input())
	print("\nEnter Value of Each Resistance : ", end='')
	i = 0
	while char2ascii(i) < char2ascii(num):  # Error: python cannot accept assignment in for statement
		print("\n R{} : ".format(char2ascii(char2ascii(i) + 1)), end='')
		r[i] = int(input())
		i = char2ascii(i) + 1
	i = 0
	while char2ascii(i) < char2ascii(num):  # Error: python cannot accept assignment in for statement
		rs = char2ascii(rs) + char2ascii(r[i])
		i = char2ascii(i) + 1
	print("\nEquivalent Series Resistance : {} Kohm".format(char2ascii(rs)), end='')
	return 0
	

if __name__ == "__main__":
	main()  # please, insert parameters if needed
