# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def sort_numbers_ascending(number: int, count: int) -> None:
	temp: int = 0
	i: int = 0
	j: int = 0
	k: int = 0
	j = 0
	while char2ascii(j) < char2ascii(count):  # Error: python cannot accept assignment in for statement
		k = char2ascii(j) + 1
		while char2ascii(k) < char2ascii(count):  # Error: python cannot accept assignment in for statement
			if char2ascii(number[j]) > char2ascii(number[k]):
				temp = char2ascii(number[j])
				number[j] = char2ascii(number[k])
				number[k] = char2ascii(temp)
			
			k = char2ascii(k) + 1
		j = char2ascii(j) + 1
	print("Numbers in ascending order:\n", end='')
	i = 0
	while char2ascii(i) < char2ascii(count):  # Error: python cannot accept assignment in for statement
		print("{}\n".format(char2ascii(number[i])), end='')
		i = char2ascii(i) + 1
	




def main() -> None:
	i: int = 0
	count: int = 0
	number: int = np.full((20), 0, dtype=object)
	print("How many numbers you are gonna enter:", end='')
	count = int(input())
	print("\nEnter the numbers one by one:", end='')
	i = 0
	while char2ascii(i) < char2ascii(count):  # Error: python cannot accept assignment in for statement
		number[i] = int(input())
		i = char2ascii(i) + 1
	sort_numbers_ascending(number, count)
	

if __name__ == "__main__":
	main()  # please, insert parameters if needed
