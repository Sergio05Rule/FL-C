# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def fm(date: int, month: int, year: int) -> int:
	fmonth: int = 0
	leap: int = 0
	if (char2ascii(year) % 100 == 0) and (char2ascii(year) % 400 != 0):
		leap = 0
	else:
		if char2ascii(year) % 4 == 0:
			leap = 1
		else:
			leap = 0
	fmonth = 3 + (2 - char2ascii(leap)) * ((char2ascii(month) + 2) / (2 * char2ascii(month))) + (5 * char2ascii(month) + char2ascii(month) / 9) / 2
	fmonth = char2ascii(fmonth) % 7
	return fmonth




def day_of_week(date: int, month: int, year: int) -> int:
	dayOfWeek: int = 0
	YY: int = char2ascii(year) % 100
	century: int = char2ascii(year) / 100
	print("\nDate: {}".format(char2ascii(date)), end='')
	print("/{}".format(char2ascii(month)), end='')
	print("/{} \n".format(char2ascii(year)), end='')
	dayOfWeek = 1.25 * char2ascii(YY) + fm(date, month, year) + char2ascii(date) - 2 * (char2ascii(century) % 4)
	dayOfWeek = char2ascii(dayOfWeek) % 7
	




def main() -> int:
	date: int = 0
	month: int = 0
	year: int = 0
	print("\nEnter the date ", end='')
	date = int(input())
	print("\nEnter the month ", end='')
	month = int(input())
	print("\nEnter the year ", end='')
	year = int(input())
	day_of_week(date, month, year)
	return 0
	

if __name__ == "__main__":
	main()  # please, insert parameters if needed
