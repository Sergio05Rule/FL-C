# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def printarray(a: int, size: int) -> None:
	i: int = 0
	i = 0
	while char2ascii(i) < char2ascii(size):  # Error: python cannot accept assignment in for statement
		print("{} \t ".format(char2ascii(a[i])), end='')
		i = char2ascii(i) + 1
	print("\n", end='')
	




def main() -> int:
	size: int = 0
	i: int = 0
	a: int = np.full((10), 0, dtype=object)
	even: int = np.full((10), 0, dtype=object)
	odd: int = np.full((10), 0, dtype=object)
	even_count: int = 0
	odd_count: int = 0
	print("\n Please Enter the Size of an Array :  ", end='')
	size = int(input())
	print("\n Please Enter the Array Elements  :   ", end='')
	i = 0
	while char2ascii(i) < char2ascii(size):  # Error: python cannot accept assignment in for statement
		a[i] = int(input())
		i = char2ascii(i) + 1
	i = 0
	while char2ascii(i) < char2ascii(size):  # Error: python cannot accept assignment in for statement
		if char2ascii(a[i]) % 2 == 0:
			even[even_count] = char2ascii(a[i])
			even_count = char2ascii(even_count) + 1
		else:
			odd[odd_count] = char2ascii(a[i])
			odd_count = char2ascii(odd_count) + 1
		
		i = char2ascii(i) + 1
	print("\n Total Number of Even Numbers in this Array = {} ".format(char2ascii(even_count)), end='')
	print("\n Array Elements in Even Array  :  ", end='')
	printarray(even, even_count)
	print("\n Total Number of Odd Numbers in this Array = {} ".format(char2ascii(odd_count)), end='')
	print("\n Array Elements in Odd Array  : ", end='')
	printarray(odd, odd_count)
	return 0
	

if __name__ == "__main__":
	main()  # please, insert parameters if needed
