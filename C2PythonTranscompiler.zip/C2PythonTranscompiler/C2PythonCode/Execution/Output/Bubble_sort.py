# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	array: int = np.full((100), 0, dtype=object)
	n: int = 0
	c: int = 0
	d: int = 0
	swap: int = 0
	print("Enter number of elements\n", end='')
	n = int(input())
	print("Enter {} integers\n".format(char2ascii(n)), end='')
	c = 0
	while char2ascii(c) < char2ascii(n):  # Error: python cannot accept assignment in for statement
		array[c] = int(input())
		c = char2ascii(c) + 1
	c = 0
	while char2ascii(c) < char2ascii(n) - 1:  # Error: python cannot accept assignment in for statement
		d = 0
		while char2ascii(d) < char2ascii(n) - char2ascii(c) - 1:  # Error: python cannot accept assignment in for statement
			if char2ascii(array[d]) > char2ascii(array[char2ascii(d) + 1]):
				swap = char2ascii(array[d])
				array[d] = char2ascii(array[char2ascii(d) + 1])
				array[char2ascii(d) + 1] = char2ascii(swap)
			
			d = char2ascii(d) + 1
		c = char2ascii(c) + 1
	print("Sorted list in ascending order:\n", end='')
	c = 0
	while char2ascii(c) < char2ascii(n):  # Error: python cannot accept assignment in for statement
		print("{}\n".format(char2ascii(array[c])), end='')
		c = char2ascii(c) + 1
	return 0
	

if __name__ == "__main__":
	main()  # please, insert parameters if needed
