# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	line: str = 0
	vowels: int = 0
	consonant: int = 0
	digit: int = 0
	print("Enter a letter: ", end='')
	line = input()
	if char2ascii(line) == char2ascii('a') or char2ascii(line) == char2ascii('e') or char2ascii(line) == char2ascii('i') or char2ascii(line) == char2ascii('o') or char2ascii(line) == char2ascii('u') or char2ascii(line) == char2ascii('A') or char2ascii(line) == char2ascii('E') or char2ascii(line) == char2ascii('I') or char2ascii(line) == char2ascii('O') or char2ascii(line) == char2ascii('U'):
		print("{} is a Vowel\n".format(ascii2char(line)), end='')
	else:
		print("{} is a Consonant\n".format(ascii2char(line)), end='')
	return 0
	

if __name__ == "__main__":
	main()  # please, insert parameters if needed
