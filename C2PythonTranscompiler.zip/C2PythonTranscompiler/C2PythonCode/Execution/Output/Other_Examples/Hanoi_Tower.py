# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def toh(num: int, x: str, y: str, z: str) -> None:
	if char2ascii(num) > 0:
		toh(char2ascii(num) - 1, x, z, y)
		print("\n{} ->".format(ascii2char(x)), end='')
		print("{}".format(ascii2char(y)), end='')
		toh(char2ascii(num) - 1, z, y, x)
		




def main() -> int:
	num: int = 0
	print("\nEnter number of plates:", end='')
	num = int(input())
	toh((char2ascii(num) - 1), 'A', 'B', 'C')
	return 0
	

if __name__ == "__main__":
	main()  # please, insert parameters if needed
