# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	weekday: int = 0
	print(" Please Enter the Day Number 1 to 7 (Consider 1= Monday, and 7 = Sunday) :  ", end='')
	weekday = int(input())
	if char2ascii(weekday) == 1:
		print("\n Today is Monday", end='')
	if char2ascii(weekday) == 2:
		print("\n Today is Tuesday", end='')
	if char2ascii(weekday) == 3:
		print("\n Today is Wednesday", end='')
	if char2ascii(weekday) == 4:
		print("\n Today is Thursday", end='')
	if char2ascii(weekday) == 5:
		print("\n Today is Friday", end='')
	if char2ascii(weekday) == 6:
		print("\n Today is Saturday", end='')
	if char2ascii(weekday) == 7:
		print("\n Today is Sunday", end='')
	if char2ascii(weekday) < 1 or char2ascii(weekday) > 7:
		print("\n Please enter Valid Number between 1 to 7", end='')
	return 0
	

if __name__ == "__main__":
	main()  # please, insert parameters if needed
