# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	circle_radius: int = 0
	pi_value: float = 3.14
	circle_area: float = 0
	circle_circumf: float = 0
	print("\nEnter radius of circle: ", end='')
	circle_radius = int(input())
	circle_area = pi_value * char2ascii(circle_radius) * char2ascii(circle_radius)
	print("\nArea of circle is: {}".format(circle_area), end='')
	circle_circumf = 2 * pi_value * char2ascii(circle_radius)
	print("\nCircumference of circle is: {}".format(circle_circumf), end='')
	return 0


if __name__ == "__main__":
	main()  # please, insert parameters if needed
