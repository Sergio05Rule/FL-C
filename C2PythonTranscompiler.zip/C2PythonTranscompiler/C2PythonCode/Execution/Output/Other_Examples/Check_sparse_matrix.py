# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	i: int = 0
	j: int = 0
	rows: int = 0
	columns: int = 0
	a: int = np.full((10 ,10), 0, dtype=object)
	Total: int = 0
	print("\n Please Enter Number of rows and columns  :  ", end='')
	i = int(input())
	j = int(input())
	print("\n Please Enter the Matrix Elements \n", end='')
	rows = 0
	while char2ascii(rows) < char2ascii(i):  # Error: python cannot accept assignment in for statement
		columns = 0
		while char2ascii(columns) < char2ascii(j):  # Error: python cannot accept assignment in for statement
			a[rows][columns] = int(input())
			columns = char2ascii(columns) + 1
		
		rows = char2ascii(rows) + 1
	rows = 0
	while char2ascii(rows) < char2ascii(i):  # Error: python cannot accept assignment in for statement
		columns = 0
		while char2ascii(columns) < char2ascii(j):  # Error: python cannot accept assignment in for statement
			if char2ascii(a[rows][columns]) == 0:
				Total = char2ascii(Total) + 1
			
			columns = char2ascii(columns) + 1
		rows = char2ascii(rows) + 1
	if char2ascii(Total) > (char2ascii(rows) * char2ascii(columns)) / 2:
		print("\n The Matrix that you entered is a Sparse Matrix ", end='')
	else:
		print("\n The Matrix that you entered is Not a Sparse Matrix ", end='')
	return 0
	

if __name__ == "__main__":
	main()  # please, insert parameters if needed
