# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	a: int = np.full((100), 0, dtype=object)
	number: int = 0
	i: int = 0
	j: int = 0
	temp: int = 0
	print("\n Please Enter the total Number of Elements  :  ", end='')
	number = int(input())
	print("\n Please Enter the Array Elements  :  ", end='')
	i = 0
	while char2ascii(i) < char2ascii(number):  # Error: python cannot accept assignment in for statement
		a[i] = int(input())
		i = char2ascii(i) + 1
	i = 0
	while char2ascii(i) < char2ascii(number):  # Error: python cannot accept assignment in for statement
		j = char2ascii(i) + 1
		while char2ascii(j) < char2ascii(number):  # Error: python cannot accept assignment in for statement
			if char2ascii(a[i]) > char2ascii(a[j]):
				temp = char2ascii(a[i])
				a[i] = char2ascii(a[j])
				a[j] = char2ascii(temp)
			
			j = char2ascii(j) + 1
		i = char2ascii(i) + 1
	print("\n Selection Sort Result : ", end='')
	i = 0
	while char2ascii(i) < char2ascii(number):  # Error: python cannot accept assignment in for statement
		print(" {} ".format(char2ascii(a[i])), end='')
		i = char2ascii(i) + 1
	print("\n", end='')
	return 0
	

if __name__ == "__main__":
	main()  # please, insert parameters if needed
