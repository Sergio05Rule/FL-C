# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	rows: int = 0
	columns: int = 0
	a: int = np.full((2 ,2), 0, dtype=object)
	determinant: int = 0
	print("\n Please Enter the 2 * 2 Matrix Elements \n ", end='')
	rows = 0
	while char2ascii(rows) < 2:  # Error: python cannot accept assignment in for statement
		columns = 0
		while char2ascii(columns) < 2:  # Error: python cannot accept assignment in for statement
			a[rows][columns] = int(input())
			columns = char2ascii(columns) + 1
		
		rows = char2ascii(rows) + 1
	determinant = (char2ascii(a[0][0]) * char2ascii(a[1][1])) - (char2ascii(a[0][1]) * char2ascii(a[1][0]))
	print("\n The determinant of 2 * 2 Matrix = {}".format(char2ascii(determinant)), end='')
	return 0


if __name__ == "__main__":
	main()  # please, insert parameters if needed
