# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	num: int = 0
	print("Enter an integer: ", end='')
	num = int(input())
	if char2ascii(num) % 2 == 0:
		print("{} is an even number".format(char2ascii(num)), end='')
	else:
		print("{} is an odd number".format(char2ascii(num)), end='')
	return 0


if __name__ == "__main__":
	main()  # please, insert parameters if needed
