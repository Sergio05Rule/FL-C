# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	num1: int = 0
	num2: int = 0
	flag_var: int = 0
	i: int = 0
	j: int = 0
	print("Enter two range(input integer numbers only):", end='')
	num1 = int(input())
	num2 = int(input())
	print("Prime numbers from {}".format(char2ascii(num1)), end='')
	print("and {} are:\n".format(char2ascii(num2)), end='')
	i = char2ascii(num1) + 1
	while char2ascii(i) < char2ascii(num2):  # Error: python cannot accept assignment in for statement
		flag_var = 0
		j = 2
		while char2ascii(j) <= char2ascii(i) / 2:  # Error: python cannot accept assignment in for statement
			if char2ascii(i) % char2ascii(j) == 0:
				flag_var = 1
				break
			
			j = char2ascii(j) + 1
		if char2ascii(flag_var) == 0:
			print("{}\n".format(char2ascii(i)), end='')
		i = char2ascii(i) + 1
	return 0
	

if __name__ == "__main__":
	main()  # please, insert parameters if needed
