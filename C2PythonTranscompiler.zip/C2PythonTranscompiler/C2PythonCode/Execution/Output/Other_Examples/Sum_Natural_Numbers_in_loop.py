# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	n: int = 0
	count: int = 0
	sum: int = 0
	print("Enter the value of n(positive integer): ", end='')
	n = int(input())
	count = 1
	while char2ascii(count) <= char2ascii(n):  # Error: python cannot accept assignment in for statement
		sum = char2ascii(sum) + char2ascii(count)
		count = char2ascii(count) + 1
	print("Sum of first {} natural numbers ".format(char2ascii(n)), end='')
	print("is: {}".format(char2ascii(sum)), end='')
	return 0
	

if __name__ == "__main__":
	main()  # please, insert parameters if needed
