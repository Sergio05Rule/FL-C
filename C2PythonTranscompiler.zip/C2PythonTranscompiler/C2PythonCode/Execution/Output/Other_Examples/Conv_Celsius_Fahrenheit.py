# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	celsius: float = 0
	fahrenheit: float = 0
	print("\nEnter temp in Celsius : ", end='')
	celsius = float(input())
	fahrenheit = (1.8 * celsius) + 32
	print("\nTemperature in Fahrenheit : {} ".format(fahrenheit), end='')
	return 0


if __name__ == "__main__":
	main()  # please, insert parameters if needed
