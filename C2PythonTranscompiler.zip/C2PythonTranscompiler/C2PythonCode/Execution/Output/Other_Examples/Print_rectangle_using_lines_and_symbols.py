# Please, check the installation of the following libraries
import typing
import numpy as np


# Return ASCII value from char, otherwise return the value itself
def char2ascii(var):
	if type(var) != str:
		return int(var) 
	else:
		return ord(var[0])


# Return char from ASCII value, otherwise return the char itself
def ascii2char(var):
	if type(var) == str:
		return var[0]
	else:
		return chr(int(var))


def main() -> int:
	i: int = 0
	j: int = 0
	i = 0
	while char2ascii(i) < 10:  # Error: python cannot accept assignment in for statement
		print("\n", end='')
		j = 0
		while char2ascii(j) < 10:  # Error: python cannot accept assignment in for statement
			if (char2ascii(i) == 0 or char2ascii(i) == 9 or char2ascii(j) == 0 or char2ascii(j) == 9):
				print("▲", end='')
			else:
				print("-", end='')
			j = char2ascii(j) + 1
		
		i = char2ascii(i) + 1
	return 0


if __name__ == "__main__":
	main()  # please, insert parameters if needed
